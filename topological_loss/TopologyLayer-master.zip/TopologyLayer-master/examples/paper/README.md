# Examples from Introductory Paper

This folder holds examples that will reproduce content from the preprint [A Topology Layer for Machine Learning](https://arxiv.org/abs/1905.12200)

## Topological Noise and Regularization

See folders `pointcloud` and `regression`

## Incorporating Topological Priors in Generative Models

In progress...

## Topological Adversarial Attacks

In progress...
