# Point Cloud Examples

`alpha.py` contains examples of point cloud optimization using the weak Alpha complex.  It will reproduce images for Figure 1 in "A Topology Layer for Machine Learning"
